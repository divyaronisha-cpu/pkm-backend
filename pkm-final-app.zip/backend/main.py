from fastapi import FastAPI, UploadFile
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

sources = []
next_id = 1

@app.post("/sources")
async def add_source(url: str = None, file: UploadFile = None):
    global next_id
    source = {
        "id": next_id,
        "title": url or (file.filename if file else f"Doc {next_id}"),
        "summary": "This is a mock summary of the saved document.",
    }
    sources.append(source)
    next_id += 1
    return {"source_id": source["id"]}

@app.get("/sources")
async def list_sources():
    return sources

@app.post("/qa")
async def qa(question: dict):
    q = question.get("question", "")
    return {
        "answer": f"Mock answer for: '{q}'.",
        "citations": [s["title"] for s in sources[:2]] if sources else [],
    }
