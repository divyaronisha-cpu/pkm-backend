import { useState } from "react";
import Library from "./components/Library";
import Ask from "./components/Ask";

export default function App() {
  const [page, setPage] = useState("library");

  return (
    <div className="min-h-screen bg-gray-100 flex flex-col">
      <header className="bg-blue-600 text-white p-4 flex justify-between">
        <h1 className="text-xl font-bold">Personal Knowledge Memory</h1>
        <nav>
          <button
            className={`px-4 ${page === "library" ? "font-bold" : ""}`}
            onClick={() => setPage("library")}
          >
            Library
          </button>
          <button
            className={`px-4 ${page === "ask" ? "font-bold" : ""}`}
            onClick={() => setPage("ask")}
          >
            Ask
          </button>
        </nav>
      </header>

      <main className="flex-1 p-6">
        {page === "library" && <Library />}
        {page === "ask" && <Ask />}
      </main>
    </div>
  );
}
