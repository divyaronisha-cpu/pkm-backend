import { useState, useEffect } from "react";
import { API_URL } from "../config";

export default function Library() {
  const [sources, setSources] = useState([]);
  const [url, setUrl] = useState("");

  const fetchSources = async () => {
    const res = await fetch(`${API_URL}/sources`);
    setSources(await res.json());
  };

  useEffect(() => {
    fetchSources();
  }, []);

  const addSource = async () => {
    await fetch(`${API_URL}/sources?url=` + encodeURIComponent(url), {
      method: "POST",
    });
    setUrl("");
    fetchSources();
  };

  return (
    <div>
      <h2 className="text-lg font-bold mb-4">My Library</h2>
      <div className="flex mb-4">
        <input
          className="flex-1 p-2 border rounded-l"
          placeholder="Enter URL..."
          value={url}
          onChange={(e) => setUrl(e.target.value)}
        />
        <button className="bg-blue-500 text-white px-4 rounded-r" onClick={addSource}>
          Save
        </button>
      </div>
      <ul>
        {sources.map((s) => (
          <li key={s.id} className="p-2 bg-white shadow rounded mb-2">
            <strong>{s.title}</strong>
            <p className="text-sm text-gray-600">{s.summary}</p>
          </li>
        ))}
      </ul>
    </div>
  );
}
