import { useState } from "react";
import { API_URL } from "../config";

export default function Ask() {
  const [q, setQ] = useState("");
  const [answer, setAnswer] = useState(null);

  const ask = async () => {
    const res = await fetch(`${API_URL}/qa`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ question: q }),
    });
    const data = await res.json();
    setAnswer(data);
  };

  return (
    <div>
      <h2 className="text-lg font-bold mb-4">Ask Your Brain</h2>
      <div className="flex mb-4">
        <input
          className="flex-1 p-2 border rounded-l"
          placeholder="Ask a question..."
          value={q}
          onChange={(e) => setQ(e.target.value)}
        />
        <button className="bg-green-500 text-white px-4 rounded-r" onClick={ask}>
          Ask
        </button>
      </div>
      {answer && (
        <div className="p-4 bg-white shadow rounded">
          <p className="mb-2">{answer.answer}</p>
          {answer.citations.length > 0 && (
            <ul className="text-sm text-gray-600">
              {answer.citations.map((c, i) => (
                <li key={i}>📖 {c}</li>
              ))}
            </ul>
          )}
        </div>
      )}
    </div>
  );
}
