# Personal Knowledge Memory (Final Build)

## Backend Deployment (Render)
1. Go to https://render.com → create account → New Web Service
2. Connect repo or upload `backend/` folder
3. Build Command: `pip install -r requirements.txt`
4. Start Command: `uvicorn main:app --host 0.0.0.0 --port $PORT`
5. Copy your public Render URL (e.g. https://your-backend.onrender.com)

## Frontend + Android
1. In `frontend/src/config.js`, set API_URL to your Render URL
2. Install dependencies:
   ```bash
   cd frontend
   npm install
   npm install @capacitor/core @capacitor/cli
   npx cap init pkm-app com.example.pkmapp
   npm run build
   npx cap add android
   npx cap copy
   npx cap open android
   ```
3. In Android Studio → Build APK → install on your phone/tablet.

Enjoy your Personal Knowledge Memory App 🚀
